#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <box2d/box2d.h>
#include <miniaudio.h>

#include <cmath>

namespace {
struct AppState {
    SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    b2WorldId world = b2_nullWorldId;
    b2BodyId box = b2_nullBodyId;
    bool ttfReady = false;
    float phase = 0.0f;
};

Uint8 pulseColor(float phase, float offset) {
    const float value = (std::sin(phase + offset) + 1.0f) * 0.5f;
    return static_cast<Uint8>(value * 255.0f);
}

void createPhysics(AppState& state) {
    b2WorldDef worldDef = b2DefaultWorldDef();
    worldDef.gravity = {0.0f, 9.8f};
    state.world = b2CreateWorld(&worldDef);

    b2BodyDef groundDef = b2DefaultBodyDef();
    groundDef.position = {0.0f, 6.0f};
    b2BodyId ground = b2CreateBody(state.world, &groundDef);
    b2Polygon groundBox = b2MakeBox(8.0f, 0.4f);
    b2ShapeDef groundShape = b2DefaultShapeDef();
    b2CreatePolygonShape(ground, &groundShape, &groundBox);

    b2BodyDef bodyDef = b2DefaultBodyDef();
    bodyDef.type = b2_dynamicBody;
    bodyDef.position = {0.0f, -3.0f};
    bodyDef.rotation = b2MakeRot(0.35f);
    state.box = b2CreateBody(state.world, &bodyDef);

    b2Polygon dynamicBox = b2MakeBox(0.8f, 0.8f);
    b2ShapeDef dynamicShape = b2DefaultShapeDef();
    dynamicShape.density = 1.0f;
    b2CreatePolygonShape(state.box, &dynamicShape, &dynamicBox);
}

void resetBox(AppState& state) {
    b2Body_SetTransform(state.box, {0.0f, -3.0f}, b2MakeRot(0.35f));
    b2Body_SetLinearVelocity(state.box, {0.0f, 0.0f});
    b2Body_SetAngularVelocity(state.box, 0.0f);
}

void destroyState(AppState* state) {
    if (state == nullptr) {
        return;
    }

    if (B2_IS_NON_NULL(state->world)) {
        b2DestroyWorld(state->world);
        state->world = b2_nullWorldId;
    }
    if (state->ttfReady) {
        TTF_Quit();
        state->ttfReady = false;
    }
    if (state->renderer != nullptr) {
        SDL_DestroyRenderer(state->renderer);
    }
    if (state->window != nullptr) {
        SDL_DestroyWindow(state->window);
    }
    delete state;
    SDL_Quit();
}
} // namespace

SDL_AppResult SDL_AppInit(void** appstate, int argc, char* argv[]) {
    (void)argc;
    (void)argv;

    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    auto* state = new AppState();
    if (!TTF_Init()) {
        SDL_Log("TTF_Init failed: %s", SDL_GetError());
        destroyState(state);
        return SDL_APP_FAILURE;
    }
    state->ttfReady = true;

    if (!SDL_CreateWindowAndRenderer("{{PROJECT_NAME}}", 960, 540, 0, &state->window, &state->renderer)) {
        SDL_Log("SDL_CreateWindowAndRenderer failed: %s", SDL_GetError());
        destroyState(state);
        return SDL_APP_FAILURE;
    }

    SDL_Log("SDL3_image version code: %d", IMG_Version());
    SDL_Log("miniaudio header version: %s", MA_VERSION_STRING);

    SDL_SetWindowResizable(state->window, true);
    SDL_SetRenderVSync(state->renderer, 1);
    createPhysics(*state);

    *appstate = state;
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void* appstate, SDL_Event* event) {
    (void)appstate;

    if (event->type == SDL_EVENT_QUIT) {
        return SDL_APP_SUCCESS;
    }
    if (event->type == SDL_EVENT_KEY_DOWN && event->key.key == SDLK_ESCAPE) {
        return SDL_APP_SUCCESS;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void* appstate) {
    auto* state = static_cast<AppState*>(appstate);
    if (state == nullptr || state->renderer == nullptr || B2_IS_NULL(state->world)) {
        return SDL_APP_FAILURE;
    }

    state->phase += 0.025f;
    b2World_Step(state->world, 1.0f / 60.0f, 4);

    b2Vec2 position = b2Body_GetPosition(state->box);
    if (position.y > 5.0f) {
        resetBox(*state);
        position = b2Body_GetPosition(state->box);
    }

    int width = 960;
    int height = 540;
    SDL_GetRenderOutputSize(state->renderer, &width, &height);

    SDL_SetRenderDrawColor(
        state->renderer,
        pulseColor(state->phase, 0.0f),
        pulseColor(state->phase, 2.0f),
        pulseColor(state->phase, 4.0f),
        SDL_ALPHA_OPAQUE
    );
    SDL_RenderClear(state->renderer);

    const float scale = 48.0f;
    const float centerX = static_cast<float>(width) * 0.5f;
    const float originY = static_cast<float>(height) * 0.35f;
    SDL_FRect rect = {
        centerX + position.x * scale - 38.0f,
        originY + position.y * scale - 38.0f,
        76.0f,
        76.0f
    };

    SDL_SetRenderDrawColor(state->renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
    SDL_RenderFillRect(state->renderer, &rect);
    SDL_RenderPresent(state->renderer);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void* appstate, SDL_AppResult result) {
    (void)result;
    destroyState(static_cast<AppState*>(appstate));
}